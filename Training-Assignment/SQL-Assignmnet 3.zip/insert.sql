INSERT INTO items(id, name, price)
VALUES
    (1, 'Canon EOS',36000),
    (2, 'Nikon DSLR',40000),
    (3, 'SONY PIXAR', 37000),
    (4, 'BRAVIA', 65000),
    (5, 'iPHONE', 45000),
    (6, 'SAMSUNG GALAXY', 40000),
    (7, 'EARPHONES, 450),
    (8, 'LAPTOP', 46000),
    (9, 'MOUSE', 800),
    (10, 'KEYBOARD', 1000),
    (11, 'Toy Car', 700),
    (12, 'Toy Phone', 500);
